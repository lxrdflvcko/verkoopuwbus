/*
# Create leads table for offer requests

1. New Tables
- `leads`
  - `id` (uuid, primary key)
  - `kenteken` (text, not null) — Dutch license plate
  - `merk` (text) — vehicle brand from RDW
  - `model` (text) — vehicle model/trade name from RDW
  - `inrichting` (text) — body type from RDW
  - `bouwjaar` (text) — year of first registration
  - `kilometerstand` (integer) — mileage
  - `brandstof` (text) — fuel type
  - `transmissie` (text) — transmission type (manual/automatic)
  - `apk_vervaldatum` (text) — MOT expiry date
  - `schade_info` (text) — damage/defects description
  - `naam` (text, not null) — contact name
  - `email` (text, not null) — contact email
  - `telefoon` (text, not null) — contact phone
  - `opmerkingen` (text) — additional comments
  - `status` (text, default 'nieuw') — lead status
  - `created_at` (timestamptz, default now())
2. Security
- Enable RLS on `leads`.
- Allow anon + authenticated INSERT (public form submissions).
- Allow authenticated SELECT/UPDATE/DELETE (admin access).
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kenteken text NOT NULL,
  merk text,
  model text,
  inrichting text,
  bouwjaar text,
  kilometerstand integer,
  brandstof text,
  transmissie text,
  apk_vervaldatum text,
  schade_info text,
  naam text NOT NULL,
  email text NOT NULL,
  telefoon text NOT NULL,
  opmerkingen text,
  status text NOT NULL DEFAULT 'nieuw',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_leads" ON leads;
CREATE POLICY "anon_insert_leads"
ON leads FOR INSERT
TO anon, authenticated
WITH CHECK (true);

DROP POLICY IF EXISTS "auth_select_leads" ON leads;
CREATE POLICY "auth_select_leads"
ON leads FOR SELECT
TO authenticated
USING (true);

DROP POLICY IF EXISTS "auth_update_leads" ON leads;
CREATE POLICY "auth_update_leads"
ON leads FOR UPDATE
TO authenticated
USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_leads" ON leads;
CREATE POLICY "auth_delete_leads"
ON leads FOR DELETE
TO authenticated
USING (true);

CREATE INDEX IF NOT EXISTS idx_leads_created_at ON leads (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_leads_kenteken ON leads (kenteken);
