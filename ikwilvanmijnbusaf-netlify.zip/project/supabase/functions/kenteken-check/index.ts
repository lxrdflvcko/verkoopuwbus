const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RDWVehicle {
  kenteken: string;
  voertuigsoort: string;
  merk: string;
  handelsbenaming: string;
  inrichting: string;
  datum_eerste_toelating: string;
  eerste_kleur: string;
  aantal_deuren: string;
  aantal_wielen: string;
  massa_ledig_voertuig: string;
  europese_voertuigcategorie: string;
  export_indicator: string;
  openstaande_terugroepactie_indicator: string;
  taxi_indicator: string;
  tellerstandoordeel: string;
  api_gekentekende_voertuigen_brandstof: string;
}

interface RDWFuel {
  brandstof_omschrijving: string;
  co2_uitstoot_gecombineerd: string;
  brandstofverbruik_gecombineerd: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const kentekenParam = url.searchParams.get("kenteken");

    if (!kentekenParam) {
      return new Response(
        JSON.stringify({ error: "Kenteken is vereist" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const kenteken = kentekenParam.toUpperCase().replace(/[^A-Z0-9]/g, "");

    if (kenteken.length < 5 || kenteken.length > 8) {
      return new Response(
        JSON.stringify({ error: "Ongeldig kenteken formaat" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const vehicleUrl = `https://opendata.rdw.nl/resource/m9d7-ebf2.json?kenteken=${encodeURIComponent(kenteken)}`;
    const vehicleRes = await fetch(vehicleUrl, {
      headers: { "Accept": "application/json" },
    });

    if (!vehicleRes.ok) {
      throw new Error(`RDW API fout: ${vehicleRes.status}`);
    }

    const vehicleData: RDWVehicle[] = await vehicleRes.json();

    if (!vehicleData || vehicleData.length === 0) {
      return new Response(
        JSON.stringify({ error: "Geen voertuig gevonden voor dit kenteken" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const vehicle = vehicleData[0];

    // Fetch fuel data
    let fuelInfo: RDWFuel | null = null;
    try {
      const fuelUrl = `https://opendata.rdw.nl/resource/8ys7-d773.json?kenteken=${encodeURIComponent(kenteken)}`;
      const fuelRes = await fetch(fuelUrl, {
        headers: { "Accept": "application/json" },
      });
      if (fuelRes.ok) {
        const fuelData: RDWFuel[] = await fuelRes.json();
        if (fuelData && fuelData.length > 0) {
          fuelInfo = fuelData[0];
        }
      }
    } catch {
      // Fuel data is optional
    }

    // Format date from YYYYMMDD to YYYY-MM-DD
    const formatDatum = (datum: string): string => {
      if (!datum || datum.length !== 8) return datum;
      return `${datum.substring(0, 4)}-${datum.substring(4, 6)}-${datum.substring(6, 8)}`;
    };

    const result = {
      kenteken: vehicle.kenteken,
      voertuigsoort: vehicle.voertuigsoort,
      merk: vehicle.merk,
      handelsbenaming: vehicle.handelsbenaming,
      inrichting: vehicle.inrichting,
      bouwjaar: formatDatum(vehicle.datum_eerste_toelating),
      kleur: vehicle.eerste_kleur,
      europese_voertuigcategorie: vehicle.europese_voertuigcategorie,
      aantal_deuren: vehicle.aantal_deuren,
      aantal_wielen: vehicle.aantal_wielen,
      massa_ledig_voertuig: vehicle.massa_ledig_voertuig,
      export_indicator: vehicle.export_indicator,
      openstaande_terugroepactie_indicator: vehicle.openstaande_terugroepactie_indicator,
      taxi_indicator: vehicle.taxi_indicator,
      tellerstandoordeel: vehicle.tellerstandoordeel,
      brandstof: fuelInfo?.brandstof_omschrijving || null,
      co2_uitstoot: fuelInfo?.co2_uitstoot_gecombineerd || null,
      brandstofverbruik: fuelInfo?.brandstofverbruik_gecombineerd || null,
    };

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Er ging iets mis bij het ophalen van de voertuiggegevens" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
