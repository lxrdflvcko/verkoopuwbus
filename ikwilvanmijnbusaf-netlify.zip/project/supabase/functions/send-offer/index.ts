import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface OfferPayload {
  kenteken: string;
  merk?: string;
  model?: string;
  inrichting?: string;
  bouwjaar?: string;
  kilometerstand?: number;
  brandstof?: string;
  transmissie?: string;
  apk_vervaldatum?: string;
  schade_info?: string;
  naam: string;
  email: string;
  telefoon: string;
  opmerkingen?: string;
  honeypot?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return new Response(
        JSON.stringify({ error: "Alleen POST verzoeken zijn toegestaan" }),
        { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const payload: OfferPayload = await req.json();

    // Honeypot spam check
    if (payload.honeypot) {
      return new Response(
        JSON.stringify({ success: true }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validation
    const required = ["kenteken", "naam", "email", "telefoon"];
    for (const field of required) {
      if (!payload[field as keyof OfferPayload]) {
        return new Response(
          JSON.stringify({ error: `Veld "${field}" is verplicht` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    for (const [k, v] of Object.entries(payload)) {
      if (typeof v === "string" && v.length > 2000) {
        return new Response(
          JSON.stringify({ error: `Veld "${k}" is te lang` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(payload.email)) {
      return new Response(
        JSON.stringify({ error: "Ongeldig e-mailadres" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Store lead in Supabase
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const { data: leadData, error: dbError } = await supabase
      .from("leads")
      .insert({
        kenteken: payload.kenteken,
        merk: payload.merk || null,
        model: payload.model || null,
        inrichting: payload.inrichting || null,
        bouwjaar: payload.bouwjaar || null,
        kilometerstand: payload.kilometerstand || null,
        brandstof: payload.brandstof || null,
        transmissie: payload.transmissie || null,
        apk_vervaldatum: payload.apk_vervaldatum || null,
        schade_info: payload.schade_info || null,
        naam: payload.naam,
        email: payload.email,
        telefoon: payload.telefoon,
        opmerkingen: payload.opmerkingen || null,
      })
      .select()
      .single();

    if (dbError) {
      throw new Error(`Database fout: ${dbError.message}`);
    }

    // Send email via Resend (API key stays server-side as a Supabase secret)
    const RECIPIENT_EMAIL = Deno.env.get("LEAD_RECIPIENT_EMAIL") || "test@test.com";
    const FROM_EMAIL = Deno.env.get("LEAD_FROM_EMAIL") || "IkWilVanMijnBusAf <onboarding@resend.dev>";
    const resendKey = Deno.env.get("RESEND_API_KEY");

    if (!resendKey) {
      throw new Error("RESEND_API_KEY ontbreekt");
    }

    const esc = (v: unknown) =>
      String(v ?? "-")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    const row = (label: string, value: unknown) =>
      `<tr><td style="padding:8px;border:1px solid #ddd;font-weight:bold;">${label}</td><td style="padding:8px;border:1px solid #ddd;">${esc(value || "-")}</td></tr>`;

    const emailHtml = `
      <h2>Nieuwe offerteaanvraag - IkWilVanMijnBusAf</h2>
      <table style="border-collapse:collapse;width:100%;font-family:Arial,sans-serif;font-size:14px;">
        ${row("Kenteken:", payload.kenteken)}
        ${row("Merk:", payload.merk)}
        ${row("Model:", payload.model)}
        ${row("Inrichting:", payload.inrichting)}
        ${row("Bouwjaar:", payload.bouwjaar)}
        ${row("Kilometerstand:", payload.kilometerstand ? Number(payload.kilometerstand).toLocaleString("nl-NL") + " km" : "-")}
        ${row("Brandstof:", payload.brandstof)}
        ${row("Transmissie:", payload.transmissie)}
        ${row("APK vervaldatum:", payload.apk_vervaldatum)}
        ${row("Schade/gebreken:", payload.schade_info)}
        ${row("Naam:", payload.naam)}
        ${row("E-mail:", payload.email)}
        ${row("Telefoon:", payload.telefoon)}
        ${row("Opmerkingen:", payload.opmerkingen)}
      </table>
      <p style="font-family:Arial,sans-serif;font-size:12px;color:#999;margin-top:16px;">Deze aanvraag is automatisch verzonden via ikwilvanmijnbusaf.nl</p>
    `;

    const mailRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${resendKey}`,
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: [RECIPIENT_EMAIL],
        reply_to: payload.email,
        subject: `Nieuwe offerteaanvraag ${payload.kenteken} - ${payload.naam}`.slice(0, 200),
        html: emailHtml,
      }),
    });

    if (!mailRes.ok) {
      // Lead is already stored in the database; surface the failure in logs only
      console.error("Resend fout:", mailRes.status, await mailRes.text());
      throw new Error("E-mail verzenden mislukt");
    }

    return new Response(
      JSON.stringify({
        success: true,
        leadId: leadData?.id,
        message: "Uw aanvraag is succesvol verzonden. Wij nemen zo snel mogelijk contact met u op.",
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: "Er ging iets mis bij het verzenden van uw aanvraag. Probeer het later opnieuw." }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
