import { Star, Quote } from 'lucide-react';
import Reveal from './Reveal';

const REVIEWS = [
  {
    name: 'Mark de Vries',
    role: 'Klant uit Amsterdam',
    rating: 5,
    text: 'Binnen een dag netjes contact opgenomen en een eerlijk bod voor mijn bestelbus gekregen. Alles is soepel en snel verlopen.',
  },
  {
    name: 'Sandra Jansen',
    role: 'Klant uit Rotterdam',
    rating: 5,
    text: 'Duidelijke communicatie en geen verrassingen. De bus werd opgehaald en het geld stond dezelfde dag op de rekening. Aanrader!',
  },
  {
    name: 'Peter Bakker',
    role: 'Klant uit Utrecht',
    rating: 5,
    text: 'Eindelijk een partij die doet wat ze beloven. Vrijblijvend bod, netjes overleg en een eerlijke prijs voor mijn werkbus.',
  },
];

export default function Reviews() {
  return (
    <section id="reviews" className="py-20 lg:py-28 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">Klantenbeoordeling</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Vertrouwen van klanten
          </h2>

          <div className="mt-6 inline-flex flex-col items-center gap-2 p-5 rounded-2xl bg-slate-50 ring-1 ring-slate-200/60">
            <div className="flex items-center gap-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            <p className="text-2xl font-extrabold text-slate-900">4,8 / 5</p>
            <p className="text-sm text-slate-500">Gebaseerd op klantbeoordelingen</p>
          </div>

          <p className="mt-6 text-lg text-slate-600">
            Een snelle afhandeling, duidelijke communicatie en persoonlijk contact staan bij ons centraal.
          </p>
        </Reveal>

        <div className="grid md:grid-cols-3 gap-6">
          {REVIEWS.map((review, idx) => (
            <Reveal key={review.name} delay={idx * 150}>
              <div className="relative p-7 rounded-2xl bg-slate-50 ring-1 ring-slate-200/60 hover:shadow-lg transition-shadow h-full">
                <Quote className="w-10 h-10 text-blue-200 mb-4" />
                <div className="flex items-center gap-1 mb-4">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-slate-700 leading-relaxed mb-6">"{review.text}"</p>
                <div className="flex items-center gap-3 pt-4 border-t border-slate-200">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-600 text-white font-bold text-sm">
                    {review.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <p className="font-semibold text-slate-900 text-sm">{review.name}</p>
                    <p className="text-xs text-slate-500">{review.role}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
