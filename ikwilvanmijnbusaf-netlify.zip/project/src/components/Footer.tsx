import { Phone, Mail, MessageCircle } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid md:grid-cols-3 gap-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <img
                src="https://i.imgur.com/QK9bohp.png"
                alt="IkWilVanMijnBusAf logo"
                className="w-11 h-11 rounded-xl object-cover ring-1 ring-slate-700"
              />
              <div className="leading-tight">
                <span className="block text-lg font-extrabold text-white tracking-tight">
                  IkWilVan<span className="text-blue-400">MijnBusAf</span>
                </span>
                <span className="block text-[11px] text-slate-500">ikwilvanmijnbusaf.nl</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed max-w-sm">
              Wij zijn de specialist in de inkoop van bedrijfswagens en bestelbussen in heel Nederland.
              Snel, persoonlijk en zonder gedoe. Vraag vandaag nog uw vrijblijvende bod aan.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Navigatie</h4>
            <ul className="space-y-3">
              <li><a href="#kentekencheck" className="text-sm hover:text-blue-400 transition-colors">Kentekencheck</a></li>
              <li><a href="#proces" className="text-sm hover:text-blue-400 transition-colors">Hoe het werkt</a></li>
              <li><a href="#voordelen" className="text-sm hover:text-blue-400 transition-colors">Voordelen</a></li>
              <li><a href="#reviews" className="text-sm hover:text-blue-400 transition-colors">Reviews</a></li>
              <li><a href="#faq" className="text-sm hover:text-blue-400 transition-colors">Veelgestelde vragen</a></li>
              <li><a href="#contact" className="text-sm hover:text-blue-400 transition-colors">Contact</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Contact</h4>
            <ul className="space-y-4">
              <li>
                <a href="tel:085-130-1900" className="flex items-center gap-3 text-sm hover:text-blue-400 transition-colors">
                  <Phone className="w-4 h-4 text-blue-500 shrink-0" />
                  085-130-1900
                </a>
              </li>
              <li>
                <a href="mailto:info@verkoopjouwbus.nl" className="flex items-center gap-3 text-sm hover:text-blue-400 transition-colors">
                  <Mail className="w-4 h-4 text-blue-500 shrink-0" />
                  info@verkoopjouwbus.nl
                </a>
              </li>
              <li>
                <a href="https://wa.me/31851301900" target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 text-sm hover:text-blue-400 transition-colors">
                  <MessageCircle className="w-4 h-4 text-blue-500 shrink-0" />
                  WhatsApp ons
                </a>
              </li>
              <li className="pt-2">
                <p className="text-sm">Openingstijden: ma–vr 08:00–18:00</p>
                <p className="text-sm">Landelijke inkoop in heel Nederland</p>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-500">
            &copy; {year} IkWilVanMijnBusAf · ikwilvanmijnbusaf.nl — Alle rechten voorbehouden.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-sm text-slate-500 hover:text-blue-400 transition-colors">Privacybeleid</a>
            <a href="#" className="text-sm text-slate-500 hover:text-blue-400 transition-colors">Algemene voorwaarden</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
