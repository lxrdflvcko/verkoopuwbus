import Reveal from './Reveal';

const BRANDS = [
  'Mercedes-Benz', 'Volkswagen', 'Ford', 'Renault',
  'Citroën', 'Peugeot', 'Opel', 'Fiat',
  'IVECO', 'Nissan', 'Toyota', 'Mitsubishi',
];

export default function Brands() {
  return (
    <section className="py-16 lg:py-20 bg-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Bedrijfswagens van vrijwel alle bekende merken
          </h2>
          <p className="mt-3 text-slate-400">
            Wij beoordelen bestelbussen, werkbussen en andere bedrijfswagens — ook met een hogere kilometerstand.
          </p>
        </Reveal>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {BRANDS.map((brand, idx) => (
            <Reveal key={brand} delay={idx * 50}>
              <div className="flex items-center justify-center px-6 py-5 rounded-xl bg-white/5 ring-1 ring-white/10 hover:bg-white/10 hover:ring-blue-400/30 transition-all h-full">
                <span className="text-lg font-bold text-slate-300 tracking-wide text-center">{brand}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
