import { Phone, Mail, MessageCircle, Clock, MapPin } from 'lucide-react';
import Reveal from './Reveal';

const CONTACT_INFO = [
  {
    icon: Phone,
    label: 'Bel ons',
    value: '085-130-1900',
    href: 'tel:085-130-1900',
    sub: 'Ma–vr 08:00–18:00',
  },
  {
    icon: Mail,
    label: 'E-mail',
    value: 'info@verkoopjouwbus.nl',
    href: 'mailto:info@verkoopjouwbus.nl',
    sub: 'Reactie binnen 24 uur',
  },
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    value: 'Stuur een bericht',
    href: 'https://wa.me/31851301900',
    sub: 'Snelle reactie',
  },
];

export default function Contact() {
  return (
    <section id="contact" className="py-20 lg:py-28 bg-white scroll-mt-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">Contact</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Liever meteen overleggen?
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Bel, mail of stuur een WhatsApp-bericht. Wij staan klaar om uw bedrijfsbus te beoordelen.
          </p>
        </Reveal>

        <div className="grid sm:grid-cols-3 gap-5">
          {CONTACT_INFO.map((item, idx) => (
            <Reveal key={item.label} delay={idx * 120}>
              <a
                href={item.href}
                target={item.href.startsWith('http') ? '_blank' : undefined}
                rel={item.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                className="group block p-7 rounded-2xl bg-slate-50 ring-1 ring-slate-200/60 hover:ring-blue-300 hover:shadow-xl hover:shadow-blue-600/5 hover:-translate-y-1 transition-all text-center h-full"
              >
                <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-blue-600 text-white mb-5 group-hover:scale-110 transition-transform shadow-lg shadow-blue-600/20 mx-auto">
                  <item.icon className="w-7 h-7" />
                </div>
                <p className="text-sm font-medium text-slate-500 mb-1">{item.label}</p>
                <p className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                  {item.value}
                </p>
                <p className="text-sm text-slate-500 mt-1">{item.sub}</p>
              </a>
            </Reveal>
          ))}
        </div>

        <Reveal className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-6 text-slate-600">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium">Openingstijden: ma–vr 08:00–18:00</span>
          </div>
          <div className="hidden sm:block w-px h-5 bg-slate-300" />
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-medium">Landelijke inkoop in heel Nederland</span>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
