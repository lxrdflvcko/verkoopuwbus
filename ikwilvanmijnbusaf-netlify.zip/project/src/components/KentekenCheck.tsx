import { useState, useRef, useCallback } from 'react';
import { Search, Loader2, Car, AlertCircle, CheckCircle2, ChevronRight, X } from 'lucide-react';
import { sanitizeKenteken, normalizeKenteken } from '@/lib/kenteken';
import type { VehicleInfo } from '@/lib/types';

interface KentekenCheckProps {
  onVehicleFound: (vehicle: VehicleInfo) => void;
  vehicle: VehicleInfo | null;
  onReset: () => void;
  onProceedToForm: () => void;
}

export default function KentekenCheck({ onVehicleFound, vehicle, onReset, onProceedToForm }: KentekenCheckProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const checkKenteken = useCallback(async (raw: string) => {
    const clean = sanitizeKenteken(raw);
    if (clean.length < 5) {
      setError('Vul een geldig kenteken in (minimaal 5 tekens).');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      const normalized = normalizeKenteken(raw);

      const res = await fetch(
        `${supabaseUrl}/functions/v1/kenteken-check?kenteken=${encodeURIComponent(normalized)}`,
        {
          headers: {
            'Authorization': `Bearer ${anonKey}`,
            'X-Client-Info': 'ikwilvanmijnbusaf',
          },
        }
      );

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        if (res.status === 404) {
          setError('Geen voertuig gevonden voor dit kenteken. Controleer het kenteken of vul handmatig in.');
        } else {
          throw new Error(body.error || `Fout (${res.status})`);
        }
        return;
      }

      const data: VehicleInfo = await res.json();
      onVehicleFound(data);
    } catch {
      setError('Kon de voertuiggegevens niet ophalen. Probeer het opnieuw of vul handmatig in.');
    } finally {
      setLoading(false);
    }
  }, [onVehicleFound]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value.toUpperCase();
    setInput(raw);

    if (vehicle) onReset();

    if (debounceRef.current) clearTimeout(debounceRef.current);

    const clean = sanitizeKenteken(raw);
    if (clean.length >= 6) {
      debounceRef.current = setTimeout(() => {
        void checkKenteken(raw);
      }, 800);
    } else {
      setError(null);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (debounceRef.current) clearTimeout(debounceRef.current);
    void checkKenteken(input);
  };

  const handleClear = () => {
    setInput('');
    setError(null);
    onReset();
  };

  const displayPlate = vehicle?.kenteken || sanitizeKenteken(input);

  return (
    <div className="w-full max-w-xl mx-auto">
      <form onSubmit={handleSubmit}>
        {/* Label */}
        <label htmlFor="kenteken-input" className="block text-sm font-semibold text-slate-200 mb-2.5 text-center sm:text-left">
          Voer uw kenteken in
        </label>

        {/* Plate + button — cohesive unit */}
        <div className="flex items-stretch gap-2 sm:gap-3 rounded-2xl bg-white/95 backdrop-blur-sm p-2 shadow-2xl shadow-slate-900/15 ring-1 ring-white/20">
          {/* Dutch plate */}
          <div className="relative flex-1 flex items-center min-w-0">
            <div className="flex items-center gap-2 w-full h-14 px-3 sm:px-4 rounded-xl bg-yellow-300 ring-2 ring-yellow-400/40 focus-within:ring-blue-500 transition-all">
              <span className="text-blue-700 font-bold text-[10px] sm:text-xs shrink-0 border-r border-blue-700/25 pr-2 leading-none">
                NL
              </span>
              <input
                id="kenteken-input"
                type="text"
                value={input}
                onChange={handleChange}
                placeholder="12-AB-34"
                maxLength={10}
                className="kenteken-plate flex-1 min-w-0 bg-transparent text-slate-900 text-lg sm:text-2xl tracking-widest outline-none placeholder:text-slate-400 placeholder:tracking-widest uppercase"
                aria-label="Kenteken invoeren"
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
                inputMode="text"
              />
              {input && !loading && (
                <button
                  type="button"
                  onClick={handleClear}
                  className="shrink-0 text-slate-400 hover:text-slate-700 transition-colors"
                  aria-label="Wissen"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
              {loading && (
                <Loader2 className="w-5 h-5 shrink-0 text-blue-600 animate-spin" />
              )}
            </div>
          </div>

          {/* Check button */}
          <button
            type="submit"
            disabled={loading || sanitizeKenteken(input).length < 5}
            className="shrink-0 inline-flex items-center justify-center gap-2 h-14 px-5 sm:px-7 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-600/20"
          >
            <Search className="w-5 h-5" />
            <span className="hidden sm:inline">Controleer</span>
          </button>
        </div>
      </form>

      {/* Error message */}
      {error && !vehicle && (
        <div className="mt-4 flex items-start gap-3 p-4 rounded-xl bg-red-50 ring-1 ring-red-200 text-red-800 animate-gentle-in">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <p className="text-sm font-medium">{error}</p>
        </div>
      )}

      {/* Vehicle result card */}
      {vehicle && (
        <div className="mt-4 p-5 rounded-2xl bg-white ring-1 ring-slate-200 shadow-lg animate-gentle-in">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-green-100 text-green-700">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-900">Voertuig herkend</p>
                <p className="text-xs text-slate-500">Gegevens via RDW</p>
              </div>
            </div>
            <div className="flex items-center px-4 py-1.5 rounded-lg bg-yellow-300 text-slate-900 font-bold text-sm tracking-widest kenteken-plate">
              {displayPlate}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <InfoCell label="Merk" value={vehicle.merk} />
            <InfoCell label="Model" value={vehicle.handelsbenaming} />
            <InfoCell label="Inrichting" value={vehicle.inrichting} />
            <InfoCell label="Bouwjaar" value={vehicle.bouwjaar} />
            <InfoCell label="Brandstof" value={vehicle.brandstof || '-'} />
            <InfoCell label="Kleur" value={vehicle.kleur} />
          </div>

          <button
            type="button"
            onClick={onProceedToForm}
            className="mt-5 w-full inline-flex items-center justify-center gap-2 h-12 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700 active:scale-[0.98] transition-all shadow-lg shadow-blue-600/20"
          >
            <Car className="w-5 h-5" />
            Naar offerteaanvraag
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      )}

      <p className="mt-4 text-center text-sm text-slate-300">
        Voer uw kenteken in voor directe voertuigherkenning en een vrijblijvend bod.
      </p>
    </div>
  );
}

function InfoCell({ label, value }: { label: string; value: string }) {
  return (
    <div className="px-3 py-2.5 rounded-lg bg-slate-50">
      <p className="text-xs font-medium text-slate-500 mb-0.5">{label}</p>
      <p className="text-sm font-semibold text-slate-900 capitalize">{value || '-'}</p>
    </div>
  );
}
