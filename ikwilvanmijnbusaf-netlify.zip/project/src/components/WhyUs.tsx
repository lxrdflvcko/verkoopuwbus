import { Zap, MessageSquare, CheckCircle2, MapPin, BadgeEuro, ShieldOff } from 'lucide-react';
import Reveal from './Reveal';

const ADVANTAGES = [
  {
    icon: Zap,
    title: 'Snelle afhandeling',
    description: 'Snel contact en duidelijke afspraken over het bod en de verdere afhandeling.',
  },
  {
    icon: MessageSquare,
    title: 'Goede communicatie',
    description: 'Persoonlijk contact en heldere uitleg tijdens het volledige verkoopproces.',
  },
  {
    icon: CheckCircle2,
    title: 'Makkelijk geregeld',
    description: 'Van aanvraag tot overdracht zo eenvoudig en overzichtelijk mogelijk geregeld.',
  },
  {
    icon: MapPin,
    title: 'Ophalen in heel Nederland',
    description: 'Wij komen uw bedrijfsbus bij u ophalen, waar u ook in Nederland bent.',
  },
  {
    icon: BadgeEuro,
    title: 'Geen verkoopkosten',
    description: 'Uw aanvraag is gratis en vrijblijvend. Geen verborgen kosten of administratiekosten.',
  },
  {
    icon: ShieldOff,
    title: 'Geen gedoe met kopers',
    description: 'Geen onderhandelingen met particuliere kopers, geen weken wachten op reacties.',
  },
];

export default function WhyUs() {
  return (
    <section id="voordelen" className="py-20 lg:py-28 bg-slate-50 scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">Waarom IkWilVanMijnBusAf</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Gericht op een snelle en duidelijke verkoop
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Geen lange advertenties plaatsen of weken wachten op onzekere reacties. U krijgt direct contact met een inkoper van bedrijfswagens.
          </p>
        </Reveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {ADVANTAGES.map((item, idx) => (
            <Reveal key={item.title} delay={idx * 80}>
              <div className="group p-7 rounded-2xl bg-white ring-1 ring-slate-200/60 hover:ring-blue-300 hover:shadow-xl hover:shadow-blue-600/5 hover:-translate-y-1 transition-all duration-300 h-full">
                <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-blue-50 text-blue-600 mb-5 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <item.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-slate-600 leading-relaxed text-[15px]">{item.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
