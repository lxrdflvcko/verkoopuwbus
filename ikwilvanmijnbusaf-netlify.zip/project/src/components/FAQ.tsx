import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import Reveal from './Reveal';

const FAQS = [
  {
    q: 'Welke bedrijfswagens kopen jullie?',
    a: 'Wij beoordelen bestelbussen, werkbussen en andere bedrijfswagens van vrijwel alle bekende merken. Ook een hogere kilometerstand is bespreekbaar.',
  },
  {
    q: 'Is een bod vrijblijvend?',
    a: 'Ja. U kunt uw voertuiggegevens doorgeven en zelf beslissen of u met het aangeboden bod verder wilt. U zit nergens aan vast.',
  },
  {
    q: 'Kopen jullie door heel Nederland?',
    a: 'Ja. De website is gericht op aanbieders van bedrijfswagens in heel Nederland. Wij komen uw bus bij u ophalen, waar u ook bent.',
  },
  {
    q: 'Hoe snel krijg ik een bod?',
    a: 'In veel gevallen ontvangt u snel een passend bod nadat u uw gegevens heeft ingevuld. De exacte doorlooptijd kan per voertuig en regio verschillen.',
  },
  {
    q: 'Kan ik ook een bus met schade verkopen?',
    a: 'Ja, ook bedrijfswagens met schade of gebreken zijn welkom. Vermeld dit bij het invullen van het formulier, zodat we een eerlijk bod kunnen uitbrengen.',
  },
  {
    q: 'Hoe wordt mijn bus opgehaald?',
    a: 'Na akkoord plannen we samen een ophaalmoment dat u uitkomt. Ophalen, betaling en overdracht regelen wij voor u, in heel Nederland.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 lg:py-28 bg-slate-50 scroll-mt-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center mb-12">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">Veelgestelde vragen</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Vragen over uw bedrijfsbus verkopen
          </h2>
        </Reveal>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <Reveal key={idx} delay={idx * 60}>
              <div
                className="rounded-xl bg-white ring-1 ring-slate-200/60 overflow-hidden hover:ring-blue-200 transition-colors"
              >
                <button
                  onClick={() => setOpen(open === idx ? null : idx)}
                  className="w-full flex items-center justify-between gap-4 px-6 py-5 text-left"
                  aria-expanded={open === idx}
                >
                  <span className="font-semibold text-slate-900 text-[15px]">{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-blue-600 shrink-0 transition-transform duration-300 ${
                      open === idx ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                <div
                  className="overflow-hidden transition-all duration-300 ease-out"
                  style={{ maxHeight: open === idx ? '300px' : '0px' }}
                >
                  <div className="px-6 pb-5 text-slate-600 leading-relaxed">
                    {faq.a}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
