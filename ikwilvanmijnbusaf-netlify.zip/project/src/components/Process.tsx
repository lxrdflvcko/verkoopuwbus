import { FileText, Handshake, Truck } from 'lucide-react';
import Reveal from './Reveal';

const STEPS = [
  {
    icon: FileText,
    title: 'Vul uw gegevens in',
    description: 'Stuur het kenteken, de kilometerstand en enkele voertuiggegevens door. Binnen enkele seconden herkennen wij uw bus.',
    step: '01',
  },
  {
    icon: Handshake,
    title: 'Ontvang een bod',
    description: 'Wij beoordelen uw bedrijfsbus en nemen persoonlijk contact met u op met een vrijblijvend bod.',
    step: '02',
  },
  {
    icon: Truck,
    title: 'Verkoop eenvoudig',
    description: 'Akkoord met het bod? Dan spreken we samen de verdere afhandeling af. Wij regelen ophaling en betaling.',
    step: '03',
  },
];

export default function Process() {
  return (
    <section id="proces" className="py-20 lg:py-28 bg-white scroll-mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Reveal className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-sm font-bold text-blue-600 uppercase tracking-wider">Hoe het werkt</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Uw bedrijfsbus verkopen in 3 stappen
          </h2>
          <p className="mt-4 text-lg text-slate-600">
            Geen lange advertenties plaatsen of weken wachten op onzekere reacties. U krijgt direct contact met een inkoper van bedrijfswagens.
          </p>
        </Reveal>

        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {STEPS.map((step, idx) => (
            <Reveal key={step.title} delay={idx * 150} className="relative group">
              {/* Connector line */}
              {idx < STEPS.length - 1 && (
                <div className="hidden md:block absolute top-14 left-[60%] right-[-40%] h-0.5 bg-gradient-to-r from-blue-200 to-transparent" />
              )}

              <div className="relative p-8 rounded-2xl bg-slate-50 ring-1 ring-slate-200/60 hover:ring-blue-300 hover:shadow-xl hover:shadow-blue-600/5 transition-all duration-300 h-full">
                <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 text-white shadow-lg shadow-blue-600/20 mb-6 group-hover:scale-110 transition-transform">
                  <step.icon className="w-7 h-7" />
                </div>

                <span className="absolute top-6 right-6 text-5xl font-extrabold text-slate-200/60 leading-none">
                  {step.step}
                </span>

                <h3 className="text-xl font-bold text-slate-900 mb-3">{step.title}</h3>
                <p className="text-slate-600 leading-relaxed">{step.description}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
