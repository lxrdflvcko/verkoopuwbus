import { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

const NAV_LINKS = [
  { href: '#kentekencheck', label: 'Kentekencheck' },
  { href: '#proces', label: 'Hoe het werkt' },
  { href: '#voordelen', label: 'Voordelen' },
  { href: '#reviews', label: 'Reviews' },
  { href: '#faq', label: 'FAQ' },
  { href: '#contact', label: 'Contact' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = () => setMenuOpen(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/95 backdrop-blur-md shadow-md py-2.5'
          : 'bg-white/80 backdrop-blur-sm py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <a href="#top" className="flex items-center gap-2.5 shrink-0" onClick={handleNavClick}>
          <img
            src="https://i.imgur.com/QK9bohp.png"
            alt="IkWilVanMijnBusAf logo"
            className="w-11 h-11 rounded-xl object-cover ring-1 ring-slate-200"
          />
          <div className="leading-tight">
            <span className="block text-lg font-extrabold text-slate-900 tracking-tight">
              IkWilVan<span className="text-blue-600">MijnBusAf</span>
            </span>
            <span className="block text-[11px] text-slate-500 font-medium -mt-0.5">
              ikwilvanmijnbusaf.nl
            </span>
          </div>
        </a>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-7">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-4">
          <a
            href="tel:085-130-1900"
            className="flex items-center gap-2 text-sm font-semibold text-slate-800 hover:text-blue-600 transition-colors"
          >
            <Phone className="w-4 h-4" />
            085-130-1900
          </a>
          <a
            href="#kentekencheck"
            className="inline-flex items-center px-5 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold hover:bg-blue-700 active:scale-95 transition-all shadow-lg shadow-blue-600/20"
          >
            Vrijblijvend bod
          </a>
        </div>

        {/* Mobile menu button */}
        <button
          className="lg:hidden flex items-center justify-center w-10 h-10 rounded-lg text-slate-700 hover:bg-slate-100 transition-colors"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu openen"
          aria-expanded={menuOpen}
        >
          {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile nav */}
      {menuOpen && (
        <nav className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-xl border-t border-slate-100 animate-slide-down">
          <div className="px-4 py-4 space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={handleNavClick}
                className="block px-4 py-3 rounded-lg text-base font-medium text-slate-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                {link.label}
              </a>
            ))}
            <div className="pt-3 mt-2 border-t border-slate-100 space-y-2">
              <a
                href="tel:085-130-1900"
                className="flex items-center gap-2 px-4 py-3 rounded-lg text-base font-semibold text-slate-800"
              >
                <Phone className="w-5 h-5 text-blue-600" />
                085-130-1900
              </a>
              <a
                href="#kentekencheck"
                onClick={handleNavClick}
                className="block w-full text-center px-5 py-3 rounded-xl bg-blue-600 text-white text-base font-semibold"
              >
                Vrijblijvend bod aanvragen
              </a>
            </div>
          </div>
        </nav>
      )}
    </header>
  );
}
