import { useState, useEffect, useRef } from 'react';
import { Loader2, CheckCircle2, AlertCircle, Send, Car, Lock } from 'lucide-react';
import type { VehicleInfo, OfferFormValues, FormStatus } from '@/lib/types';
import { sanitizeKenteken } from '@/lib/kenteken';

interface OfferFormProps {
  vehicle: VehicleInfo | null;
  scrollTrigger: number;
}

const INITIAL_VALUES: OfferFormValues = {
  kenteken: '',
  merk: '',
  model: '',
  inrichting: '',
  bouwjaar: '',
  kilometerstand: null,
  brandstof: '',
  transmissie: '',
  apk_vervaldatum: '',
  schade_info: '',
  naam: '',
  email: '',
  telefoon: '',
  opmerkingen: '',
  honeypot: '',
};

function buildValuesFromVehicle(v: VehicleInfo): OfferFormValues {
  return {
    ...INITIAL_VALUES,
    kenteken: v.kenteken,
    merk: v.merk || '',
    model: v.handelsbenaming || '',
    inrichting: v.inrichting || '',
    bouwjaar: v.bouwjaar || '',
    brandstof: v.brandstof || '',
    transmissie: '',
  };
}

export default function OfferForm({ vehicle, scrollTrigger }: OfferFormProps) {
  const [values, setValues] = useState<OfferFormValues>(INITIAL_VALUES);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<FormStatus>('idle');
  const formRef = useRef<HTMLDivElement>(null);

  // Sync form when vehicle changes
  useEffect(() => {
    if (vehicle) {
      setValues(buildValuesFromVehicle(vehicle));
    }
  }, [vehicle]);

  // Scroll to form when scrollTrigger changes (from "Naar offerteaanvraag" click)
  useEffect(() => {
    if (scrollTrigger > 0) {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [scrollTrigger]);

  const updateField = (field: keyof OfferFormValues, value: string | number | null) => {
    setValues((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const validate = (): boolean => {
    const e: Record<string, string> = {};

    if (!values.kenteken.trim()) e.kenteken = 'Vul uw kenteken in';
    if (!values.naam.trim()) e.naam = 'Vul uw naam in';
    if (!values.email.trim()) {
      e.email = 'Vul uw e-mailadres in';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
      e.email = 'Vul een geldig e-mailadres in';
    }
    if (!values.telefoon.trim()) {
      e.telefoon = 'Vul uw telefoonnummer in';
    } else if (values.telefoon.replace(/[^0-9]/g, '').length < 10) {
      e.telefoon = 'Vul een geldig telefoonnummer in';
    }

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (values.honeypot) return;
    if (!validate()) return;

    setStatus('loading');

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const payload = {
        ...values,
        kenteken: sanitizeKenteken(values.kenteken),
        kilometerstand: values.kilometerstand || null,
      };

      const res = await fetch(`${supabaseUrl}/functions/v1/send-offer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${anonKey}`,
          'X-Client-Info': 'ikwilvanmijnbusaf',
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error || `Fout (${res.status})`);
      }

      const data = await res.json();
      if (!data.success) throw new Error('Verzenden mislukt');

      setStatus('success');
    } catch {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <div className="max-w-2xl mx-auto p-8 sm:p-10 rounded-2xl bg-white ring-1 ring-slate-200 shadow-xl text-center animate-gentle-in">
        <div className="flex items-center justify-center w-16 h-16 rounded-full bg-green-100 text-green-600 mx-auto mb-6">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <h3 className="text-2xl font-extrabold text-slate-900 mb-3">Aanvraag verzonden!</h3>
        <p className="text-slate-600 leading-relaxed mb-2">
          Bedankt voor uw aanvraag. Wij hebben uw gegevens ontvangen en nemen zo snel mogelijk persoonlijk contact met u op.
        </p>
        <p className="text-sm text-slate-500 mb-8">
          U ontvangt een bevestiging op uw e-mailadres.
        </p>
        <button
          onClick={() => {
            setStatus('idle');
            setValues(INITIAL_VALUES);
          }}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors"
        >
          Nieuwe aanvraag
        </button>
      </div>
    );
  }

  return (
    <div ref={formRef} id="offeraanvraag" className="scroll-mt-24 max-w-2xl mx-auto p-6 sm:p-8 rounded-2xl bg-white ring-1 ring-slate-200 shadow-xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="flex items-center justify-center w-11 h-11 rounded-xl bg-blue-600 text-white shrink-0">
          <Car className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-xl font-extrabold text-slate-900">Offerteaanvraag</h3>
          <p className="text-sm text-slate-500">Vul de gegevens in voor een vrijblijvend bod</p>
        </div>
      </div>

      {/* Prefilled vehicle summary from RDW */}
      {vehicle && (
        <div className="mb-6 p-5 rounded-xl bg-blue-50 ring-1 ring-blue-200">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0" />
            <p className="text-sm font-semibold text-blue-900">Voertuiggegevens overgenomen uit RDW</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 text-sm">
            <VehicleDetail label="Kenteken" value={vehicle.kenteken} />
            <VehicleDetail label="Merk" value={vehicle.merk} />
            <VehicleDetail label="Model" value={vehicle.handelsbenaming} />
            <VehicleDetail label="Inrichting" value={vehicle.inrichting} />
            <VehicleDetail label="Bouwjaar" value={vehicle.bouwjaar} />
            <VehicleDetail label="Brandstof" value={vehicle.brandstof || ''} />
            <VehicleDetail label="Kleur" value={vehicle.kleur} />
            <VehicleDetail label="Voertuigsoort" value={vehicle.voertuigsoort} />
            <VehicleDetail label="Wielen" value={vehicle.aantal_wielen} />
          </div>
        </div>
      )}

      {status === 'error' && (
        <div className="mb-6 flex items-start gap-3 p-4 rounded-xl bg-red-50 ring-1 ring-red-200 text-red-800">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <p className="text-sm font-medium">
            Er ging iets mis bij het verzenden. Probeer het opnieuw of bel ons op 085-130-1900.
          </p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5" noValidate>
        {/* Honeypot */}
        <input
          type="text"
          name="website"
          value={values.honeypot}
          onChange={(e) => updateField('honeypot', e.target.value)}
          className="absolute opacity-0 pointer-events-none -left-[9999px]"
          tabIndex={-1}
          autoComplete="off"
          aria-hidden="true"
        />

        {/* Vehicle section */}
        <div className="grid sm:grid-cols-2 gap-4">
          <Field
            label="Kenteken *"
            error={errors.kenteken}
            value={values.kenteken}
            onChange={(v) => updateField('kenteken', v.toUpperCase())}
            placeholder="12-AB-34"
            uppercase
            filled={!!vehicle}
          />
          <Field
            label="Kilometerstand"
            value={values.kilometerstand?.toString() || ''}
            onChange={(v) => updateField('kilometerstand', v ? parseInt(v, 10) : null)}
            placeholder="bijv. 150000"
            type="number"
          />
          <Field
            label="Merk"
            value={values.merk}
            onChange={(v) => updateField('merk', v)}
            placeholder="bijv. Mercedes-Benz"
            filled={!!vehicle}
          />
          <Field
            label="Model"
            value={values.model}
            onChange={(v) => updateField('model', v)}
            placeholder="bijv. Sprinter"
            filled={!!vehicle}
          />
          <Field
            label="Inrichting"
            value={values.inrichting}
            onChange={(v) => updateField('inrichting', v)}
            placeholder="bijv. Gesloten bestelbus"
            filled={!!vehicle}
          />
          <Field
            label="Bouwjaar"
            value={values.bouwjaar}
            onChange={(v) => updateField('bouwjaar', v)}
            placeholder="bijv. 2019"
            filled={!!vehicle}
          />
          <Field
            label="Brandstof"
            value={values.brandstof}
            onChange={(v) => updateField('brandstof', v)}
            placeholder="bijv. Diesel"
            filled={!!vehicle}
          />
          <SelectField
            label="Transmissie"
            value={values.transmissie}
            onChange={(v) => updateField('transmissie', v)}
            options={['Onbekend', 'Handgeschakeld', 'Automaat']}
          />
        </div>

        <Field
          label="APK vervaldatum"
          value={values.apk_vervaldatum}
          onChange={(v) => updateField('apk_vervaldatum', v)}
          placeholder="bijv. 2025-12-01"
        />

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">
            Schade of gebreken
          </label>
          <textarea
            value={values.schade_info}
            onChange={(e) => updateField('schade_info', e.target.value)}
            rows={3}
            placeholder="Beschrijf eventuele schades of gebreken, of laat leeg als dit niet van toepassing is."
            className="w-full px-4 py-3 rounded-xl ring-1 ring-slate-300 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[15px] resize-y"
          />
        </div>

        {/* Contact section */}
        <div className="pt-2 border-t border-slate-200">
          <h4 className="text-sm font-bold text-slate-500 uppercase tracking-wider mt-4 mb-4">Contactgegevens</h4>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field
            label="Naam *"
            error={errors.naam}
            value={values.naam}
            onChange={(v) => updateField('naam', v)}
            placeholder="Uw naam"
          />
          <Field
            label="Telefoonnummer *"
            error={errors.telefoon}
            value={values.telefoon}
            onChange={(v) => updateField('telefoon', v)}
            placeholder="bijv. 06-12345678"
            type="tel"
          />
        </div>

        <Field
          label="E-mailadres *"
          error={errors.email}
          value={values.email}
          onChange={(v) => updateField('email', v)}
          placeholder="naam@voorbeeld.nl"
          type="email"
        />

        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-1.5">
            Opmerkingen
          </label>
          <textarea
            value={values.opmerkingen}
            onChange={(e) => updateField('opmerkingen', e.target.value)}
            rows={3}
            placeholder="Eventuele aanvullende informatie of vragen."
            className="w-full px-4 py-3 rounded-xl ring-1 ring-slate-300 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[15px] resize-y"
          />
        </div>

        <button
          type="submit"
          disabled={status === 'loading'}
          className="w-full inline-flex items-center justify-center gap-2 h-14 rounded-xl bg-blue-600 text-white font-semibold text-lg hover:bg-blue-700 active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed transition-all shadow-lg shadow-blue-600/20"
        >
          {status === 'loading' ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Verzenden...
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              Verstuur aanvraag
            </>
          )}
        </button>

        <div className="flex items-center justify-center gap-2 text-slate-400">
          <Lock className="w-3.5 h-3.5" />
          <p className="text-xs">
            Uw aanvraag is gratis en vrijblijvend. Wij nemen zo snel mogelijk contact met u op.
          </p>
        </div>
      </form>
    </div>
  );
}

function VehicleDetail({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span className="text-blue-600 font-medium">{label}:</span>{' '}
      <span className="text-slate-800 font-semibold capitalize">{value || '-'}</span>
    </div>
  );
}

// --- Field helpers ---

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
  error,
  uppercase,
  filled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  error?: string;
  uppercase?: boolean;
  filled?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full px-4 py-3 rounded-xl ring-1 outline-none transition-all text-[15px] ${
          error
            ? 'ring-2 ring-red-400 focus:ring-red-500'
            : filled
            ? 'ring-2 ring-blue-400 bg-blue-50/50 focus:ring-2 focus:ring-blue-500'
            : 'ring-slate-300 focus:ring-2 focus:ring-blue-500'
        } ${uppercase ? 'uppercase' : ''}`}
      />
      {error && <p className="mt-1.5 text-sm text-red-600 font-medium">{error}</p>}
    </div>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <label className="block text-sm font-semibold text-slate-700 mb-1.5">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-3 rounded-xl ring-1 ring-slate-300 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-[15px] bg-white"
      >
        <option value="">{label === 'Transmissie' ? 'Selecteer...' : 'Kies...'}</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    </div>
  );
}
