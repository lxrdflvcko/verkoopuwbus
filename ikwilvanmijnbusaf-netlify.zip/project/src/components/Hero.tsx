import { Truck, ShieldCheck, Clock, TrendingDown } from 'lucide-react';
import KentekenCheck from './KentekenCheck';
import type { VehicleInfo } from '@/lib/types';

interface HeroProps {
  onVehicleFound: (v: VehicleInfo) => void;
  vehicle: VehicleInfo | null;
  onReset: () => void;
  onProceedToForm: () => void;
}

const HERO_IMAGE = 'https://images.pexels.com/photos/12700835/pexels-photo-12700835.jpeg?auto=compress&cs=tinysrgb&w=1600';

export default function Hero({ onVehicleFound, vehicle, onReset, onProceedToForm }: HeroProps) {
  return (
    <section id="top" className="relative min-h-[680px] lg:min-h-[760px] flex items-center pt-28 pb-16 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_IMAGE}
          alt="Bedrijfswagens geparkeerd"
          className="w-full h-full object-cover"
          loading="eager"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/90 via-slate-900/80 to-blue-900/85" />
        <div className="absolute inset-0 bg-grid opacity-30" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-12 items-center">
          {/* Left: headline */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/15 ring-1 ring-blue-400/30 text-blue-200 text-sm font-medium mb-6 animate-hero-in">
              <ShieldCheck className="w-4 h-4" />
              Landelijke inkoop van bedrijfswagens
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-[1.1] tracking-tight text-balance animate-hero-in" style={{ animationDelay: '0.1s' }}>
              Uw bedrijfsbus verkopen{' '}
              <span className="text-blue-400">zonder gedoe</span>
            </h1>

            <p className="mt-5 text-lg text-slate-300 max-w-xl mx-auto lg:mx-0 leading-relaxed animate-hero-in" style={{ animationDelay: '0.2s' }}>
              Vul uw kenteken in en ontvang snel een vrijblijvend bod op uw bedrijfsbus.
              Persoonlijk contact, duidelijke afspraken en landelijke inkoop zonder onnodig gedoe.
            </p>

            {/* Trust badges */}
            <div className="mt-8 flex flex-wrap justify-center lg:justify-start gap-x-6 gap-y-3 animate-hero-in" style={{ animationDelay: '0.3s' }}>
              <TrustBadge icon={<Clock className="w-4 h-4" />} text="Snel contact" />
              <TrustBadge icon={<ShieldCheck className="w-4 h-4" />} text="Vrijblijvend bod" />
              <TrustBadge icon={<Truck className="w-4 h-4" />} text="Inkoop in heel Nederland" />
              <TrustBadge icon={<TrendingDown className="w-4 h-4" />} text="Geen verkoopkosten" />
            </div>
          </div>

          {/* Right: kenteken check */}
          <div id="kentekencheck" className="scroll-mt-24 animate-hero-in" style={{ animationDelay: '0.4s' }}>
            <KentekenCheck onVehicleFound={onVehicleFound} vehicle={vehicle} onReset={onReset} onProceedToForm={onProceedToForm} />
          </div>
        </div>
      </div>
    </section>
  );
}

function TrustBadge({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-2 text-slate-300">
      <span className="flex items-center justify-center w-7 h-7 rounded-full bg-white/10 text-blue-300">
        {icon}
      </span>
      <span className="text-sm font-medium">{text}</span>
    </div>
  );
}
