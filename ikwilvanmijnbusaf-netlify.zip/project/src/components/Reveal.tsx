import type { ReactNode } from 'react';
import { useScrollReveal } from '@/lib/useScrollReveal';

interface RevealProps {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: 'div' | 'section' | 'article' | 'li';
}

/**
 * Wraps children in a scroll-triggered fade animation.
 * Gentle opacity + small translate for a smooth, non-jarring reveal.
 */
export default function Reveal({ children, delay = 0, className = '', as = 'div' }: RevealProps) {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  const Tag = as as 'div';

  return (
    <Tag
      ref={ref}
      className={`transition-all duration-[800ms] ease-[cubic-bezier(0.16,1,0.3,1)] ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      } ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
