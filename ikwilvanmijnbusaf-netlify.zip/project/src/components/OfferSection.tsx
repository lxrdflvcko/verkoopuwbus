import OfferForm from './OfferForm';
import type { VehicleInfo } from '@/lib/types';

interface OfferSectionProps {
  vehicle: VehicleInfo | null;
  scrollTrigger: number;
}

export default function OfferSection({ vehicle, scrollTrigger }: OfferSectionProps) {
  return (
    <section className="relative py-20 lg:py-28 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 overflow-hidden">
      {/* Decorative grid */}
      <div className="absolute inset-0 bg-grid opacity-20" />

      {/* Decorative blobs */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-sm font-bold text-blue-300 uppercase tracking-wider">Vrijblijvend bod</span>
          <h2 className="mt-2 text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Vraag vandaag nog een vrijblijvend bod aan
          </h2>
          <p className="mt-4 text-lg text-slate-300">
            Vul onderstaand formulier in en wij nemen zo snel mogelijk persoonlijk contact met u op.
            Inkoop van bedrijfswagens door heel Nederland.
          </p>
        </div>

        <OfferForm vehicle={vehicle} scrollTrigger={scrollTrigger} />
      </div>
    </section>
  );
}
