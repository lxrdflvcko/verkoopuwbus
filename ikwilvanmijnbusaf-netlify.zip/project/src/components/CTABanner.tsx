import { ArrowRight } from 'lucide-react';
import Reveal from './Reveal';

interface CTABannerProps {
  onCTAClick: () => void;
}

export default function CTABanner({ onCTAClick }: CTABannerProps) {
  return (
    <section className="relative py-16 bg-blue-600 overflow-hidden">
      <div className="absolute inset-0 bg-grid opacity-15" />
      <div className="absolute top-0 right-0 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl" />

      <Reveal className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight text-balance">
          Klaar om uw bedrijfsbus te verkopen?
        </h2>
        <p className="mt-3 text-blue-100 text-lg">
          Vul uw kenteken in en ontvang binnen enkele seconden een vrijblijvend bod.
        </p>
        <button
          onClick={onCTAClick}
          className="mt-7 inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-white text-blue-700 font-bold text-lg hover:bg-blue-50 active:scale-95 transition-all shadow-xl shadow-blue-900/20"
        >
          Start kentekencheck
          <ArrowRight className="w-5 h-5" />
        </button>
      </Reveal>
    </section>
  );
}
