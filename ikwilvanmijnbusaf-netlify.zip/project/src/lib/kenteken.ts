/**
 * Strip all non-alphanumeric characters and uppercase.
 */
export function sanitizeKenteken(input: string): string {
  return input.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

/**
 * Get the raw kenteken for API calls (no dashes, uppercase).
 */
export function normalizeKenteken(input: string): string {
  return sanitizeKenteken(input);
}

/**
 * Format a kenteken with dashes — but only if we can confidently detect
 * the sidecode from the *complete* alphanumeric string. While the user
 * is still typing we leave their input untouched so they can type dashes
 * and partial plates freely.
 *
 * Only formats when the clean string is exactly 6 characters (the most
 * common Dutch sidecodes: XX-99-XX, 99-XX-XX, etc.) or exactly 5/7.
 */
export function formatKenteken(input: string): string {
  const clean = sanitizeKenteken(input);
  if (clean.length < 5 || clean.length > 7) return input;

  // 6-char sidecodes
  const six = [
    /^([A-Z]{2})(\d{2})([A-Z]{2})$/,
    /^(\d{2})([A-Z]{2})([A-Z]{2})$/,
    /^([A-Z]{2})([A-Z]{2})(\d{2})$/,
    /^(\d{2})([A-Z]{2})(\d{2})$/,
    /^(\d{2})(\d{2})([A-Z]{2})$/,
    /^([A-Z]{2})(\d{2})(\d{2})$/,
  ];
  // 5-char sidecodes
  const five = [
    /^(\d{2})([A-Z]{3})$/,
    /^([A-Z]{3})(\d{2})$/,
    /^(\d{3})([A-Z]{2})$/,
    /^([A-Z]{2})(\d{3})$/,
    /^(\d{2})(\d{3})$/,
  ];
  // 7-char sidecodes
  const seven = [
    /^([A-Z]{3})(\d{3})$/,
    /^(\d{3})([A-Z]{3})$/, // less common but valid
  ];

  const codes = clean.length === 6 ? six : clean.length === 5 ? five : seven;

  for (const re of codes) {
    const m = clean.match(re);
    if (m) return m.slice(1).join("-");
  }

  // Doesn't match a known sidecode — return as-is, let the API decide
  return input;
}

/**
 * Basic sanity check: 5-7 alphanumeric characters after stripping.
 * We do NOT enforce strict sidecode matching here — the RDW API is
 * the source of truth. We only prevent obviously-too-short / too-long
 * input from triggering a lookup.
 */
export function isValidKenteken(input: string): boolean {
  const clean = sanitizeKenteken(input);
  return clean.length >= 5 && clean.length <= 8;
}
