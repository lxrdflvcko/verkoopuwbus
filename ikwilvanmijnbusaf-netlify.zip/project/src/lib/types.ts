export interface VehicleInfo {
  kenteken: string;
  voertuigsoort: string;
  merk: string;
  handelsbenaming: string;
  inrichting: string;
  bouwjaar: string;
  kleur: string;
  europese_voertuigcategorie: string;
  aantal_deuren: string;
  aantal_wielen: string;
  massa_ledig_voertuig: string;
  export_indicator: string;
  openstaande_terugroepactie_indicator: string;
  taxi_indicator: string;
  tellerstandoordeel: string;
  brandstof: string | null;
  co2_uitstoot: string | null;
  brandstofverbruik: string | null;
}

export interface OfferFormValues {
  kenteken: string;
  merk: string;
  model: string;
  inrichting: string;
  bouwjaar: string;
  kilometerstand: number | null;
  brandstof: string;
  transmissie: string;
  apk_vervaldatum: string;
  schade_info: string;
  naam: string;
  email: string;
  telefoon: string;
  opmerkingen: string;
  honeypot: string;
}

export type FormStatus = "idle" | "loading" | "success" | "error";
