import { useState, useCallback } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Process from '@/components/Process';
import WhyUs from '@/components/WhyUs';
import Brands from '@/components/Brands';
import Reviews from '@/components/Reviews';
import CTABanner from '@/components/CTABanner';
import OfferSection from '@/components/OfferSection';
import FAQ from '@/components/FAQ';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import type { VehicleInfo } from '@/lib/types';

export default function App() {
  const [vehicle, setVehicle] = useState<VehicleInfo | null>(null);
  const [scrollTrigger, setScrollTrigger] = useState(0);

  const handleVehicleFound = useCallback((v: VehicleInfo) => {
    setVehicle(v);
  }, []);

  const handleReset = useCallback(() => {
    setVehicle(null);
  }, []);

  const scrollToKenteken = useCallback(() => {
    document.getElementById('kentekencheck')?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  // Called when user clicks "Naar offerteaanvraag" in the kenteken result card.
  // The incrementing counter triggers the useEffect inside OfferForm that scrolls
  // and re-populates from the latest vehicle data.
  const scrollToForm = useCallback(() => {
    setScrollTrigger((n) => n + 1);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero
          onVehicleFound={handleVehicleFound}
          vehicle={vehicle}
          onReset={handleReset}
          onProceedToForm={scrollToForm}
        />
        <Process />
        <WhyUs />
        <Brands />
        <Reviews />
        <CTABanner onCTAClick={scrollToKenteken} />
        <OfferSection vehicle={vehicle} scrollTrigger={scrollTrigger} />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
